(function(){
var app = angular.module('store',[]);
app.controller('storecontroller',function(){
this.product = gem;
});
var gem = [ 
{
name: 'dodecahedron',
price: 2.95,
description: '. . .',
image:'images.jpg',
},
{
name: 'dodecahedron',
price: 2.95,
description: '. . .',
image:'images.jpg',
},
{
name: 'dodecahedron',
price: 2.95,
description: '. . .',
image:'images.jpg',
}
];
})();
